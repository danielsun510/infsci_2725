/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.DA.assignment1.Query;

/**
 *
 * @author Dan
 */
public class DA_Main {
    
  public static void main(String args[])throws Exception{
      
      Question1 q1= new Question1();
      Question2 q2= new Question2();
      Question3 q3= new Question3();
      Question4 q4= new Question4();
      
      Demonstrate demonstrate = new Demonstrate();
      
      //q1.Answer();
      //q2.Answer();
    // q3.Answer();
     // q4.Answer();
      //q5.Answer();
      
      demonstrate.Answer();
      
      
  }  
    
    
}
